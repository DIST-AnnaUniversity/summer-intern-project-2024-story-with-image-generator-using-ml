import React from 'react';

const ProfilePage = () => {
  return (
    <div className="profile-page">
      <h2>Profile Page</h2>
      <p>Welcome to your profile! Here you can manage your account settings and preferences.</p>
      {/* You can add more details like user profile info, settings, etc. */}
    </div>
  );
};

export default ProfilePage;
