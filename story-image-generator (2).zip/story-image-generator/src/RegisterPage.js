import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './RegisterPage.css';

const RegisterPage = () => {
    const navigate = useNavigate(); // Initialize useNavigate
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [mobile, setMobile] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault(); // Prevent default form submission

        // Create a user object
        const user = { username, email, password, mobile };

        // Log the user data to the console (simulating a registration process)
        console.log('Registration Data:', user);
        
        // Save user data to local storage
        const existingUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];
        existingUsers.push(user);
        localStorage.setItem('registeredUsers', JSON.stringify(existingUsers));

        alert('User registered successfully!'); // Show success message

        // Reset form fields
        setUsername('');
        setEmail('');
        setPassword('');
        setMobile('');

        // Redirect to the Story Generator page
        navigate('/story-generator'); // Add this line for redirection
    };

    return (
        <div className="container">
            <form onSubmit={handleSubmit}>
                <h2>Registration</h2>

                <label htmlFor="username">Username:</label>
                <input
                    type="text"
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />

                <label htmlFor="email">Email ID:</label>
                <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />

                <label htmlFor="password">Password:</label>
                <input
                    type="password"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />

                <label htmlFor="mobile">Mobile:</label>
                <input
                    type="tel"
                    id="mobile"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    required
                />

                <input type="submit" value="Sign Up" />
                <p>Already have an account? <a href="/login">Login</a></p>
            </form>
        </div>
    );
};

export default RegisterPage;
