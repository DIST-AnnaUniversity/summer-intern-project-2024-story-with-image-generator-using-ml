import React, { useState } from 'react';

const LoginPage = ({ onLogin, toggleView }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        
        // Get the list of registered users from local storage
        const existingUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];
        
        // Check if the user exists
        const user = existingUsers.find(user => user.username === username && user.password === password);

        if (user) {
            if (typeof onLogin === 'function') {
                onLogin({ username, password });
            }
            setUsername('');
            setPassword('');
            setError('');
        } else {
            setError('Invalid username or password.');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Login</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <label htmlFor="username">Username:</label>
            <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
            />
            <label htmlFor="password">Password:</label>
            <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
            />
            <input type="submit" value="Login" />
            <p>
                Don't have an account? 
                <button type="button" onClick={toggleView}>Register</button>
            </p>
        </form>
    );
};

export default LoginPage;
