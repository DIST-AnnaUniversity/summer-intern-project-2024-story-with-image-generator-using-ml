import React, { useEffect, useState } from 'react';
import './HistoryPage.css'; // Make sure to create a CSS file for styling

const HistoryPage = () => {
  const [historyItems, setHistoryItems] = useState([]);

  useEffect(() => {
    // Fetch history from local storage
    const fetchHistory = () => {
      const storedHistory = JSON.parse(localStorage.getItem('storyHistory')) || [];
      setHistoryItems(storedHistory);
    };

    fetchHistory();
  }, []);

  return (
    <div className="history-container">
      <h1>History of Generated Content</h1>
      {historyItems.length === 0 ? (
        <p>No stories or images generated yet.</p>
      ) : (
        <ul className="history-list">
          {historyItems.map((item, index) => (
            <li key={index} className="history-item">
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <p><strong>Created on:</strong> {new Date(item.createdAt).toLocaleString()}</p>
              <p><strong>Liked:</strong> {item.liked ? 'Yes' : 'No'}</p> {/* Display liked status */}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default HistoryPage;
