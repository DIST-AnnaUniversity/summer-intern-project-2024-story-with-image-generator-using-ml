import React, { useState } from 'react';
import '@fortawesome/fontawesome-free/css/all.min.css'; // Import Font Awesome

const StoryGenerator = () => {
  const [story, setStory] = useState('');
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [prompt, setPrompt] = useState('');
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false); // Use liked status

  // Function to generate a story
  const generateStory = async (inputPrompt) => {
    setLoading(true);
    setError('');

    if (!inputPrompt) {
      setError('Please enter a prompt.');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('http://127.0.0.1:5000/generate-fairy-tale', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: inputPrompt }),
      });

      if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(`Server Error: ${errorMessage}`);
      }

      const data = await response.json();
      setStory(data.story);
      await generatePhoto(inputPrompt); // Use Stable Diffusion for photo generation
      setLiked(false); // Reset liked status

      // Save history to local storage
      const historyItem = {
        title: inputPrompt,
        description: data.story,
        createdAt: new Date().toISOString(),
        liked: false, // Initialize liked status as false
      };

      // Get existing history from local storage
      const existingHistory = JSON.parse(localStorage.getItem('storyHistory')) || [];
      existingHistory.push(historyItem);
      localStorage.setItem('storyHistory', JSON.stringify(existingHistory));

    } catch (error) {
      console.error('Error generating story:', error);
      setError(`Error generating story: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Function to fetch photos from Stable Diffusion API
  const generatePhoto = async (inputPrompt) => {
    setLoading(true);
    setError('');
    const apiUrl = 'https://api.stability.ai/v2beta/stable-image/generate/core'; // Stable Diffusion API endpoint
    const apiKey = 'sk-ePKhVWk04YX26fs4BjRgzPpJAHW0dh9ZD7l0fZOCMHzszljE'; // Your Stability API Key

    const formData = new FormData();
    formData.append('prompt', inputPrompt);
    formData.append('output_format', 'webp'); // Adjust output format as needed

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Accept': 'image/*',
        },
        body: formData,
      });

      if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(`Failed to fetch photos: ${errorMessage}`);
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob); // Create a local URL for the blob
      setPhotos([url]); // Set the generated photo URL to the state
    } catch (error) {
      console.error('Error fetching photos:', error);
      setError(`Failed to fetch photos: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Function to copy text to clipboard
  const copyToClipboard = async () => {
    if (story) {
      try {
        await navigator.clipboard.writeText(story);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (error) {
        console.error('Failed to copy text:', error);
      }
    }
  };

  // Function to read the story aloud
  const readAloud = () => {
    if (story) {
      const utterance = new SpeechSynthesisUtterance(story);
      window.speechSynthesis.speak(utterance);
    }
  };

  // Function to toggle liked status
  const toggleLike = () => {
    setLiked((prevLiked) => {
      const newLikedStatus = !prevLiked;
      const existingHistory = JSON.parse(localStorage.getItem('storyHistory')) || [];
      const lastHistoryItem = existingHistory[existingHistory.length - 1];

      if (lastHistoryItem) {
        lastHistoryItem.liked = newLikedStatus;
        localStorage.setItem('storyHistory', JSON.stringify(existingHistory));
      }
      return newLikedStatus;
    });
  };

  // Function to regenerate the story
  const regenerateStory = () => {
    setPrompt('');
    setStory('');
    setPhotos([]);
    setLiked(false);
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <textarea
          id="story-input"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter your prompt here"
          style={{
            flex: 1,
            marginRight: '10px',
            padding: '10px',
            borderRadius: '8px',
            border: '1px solid #ccc',
            boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
            resize: 'none',
            fontSize: '16px',
            height: '100px',
          }}
        />
        <button onClick={() => generateStory(prompt)} className="icon-button">
          <i className="fas fa-pencil-alt"></i>
        </button>
        <button onClick={() => generatePhoto(prompt)} className="icon-button" style={{ marginLeft: '5px' }}>
          <i className="fas fa-camera"></i>
        </button>
      </div>
      {loading && <div id="spinner" style={{ display: 'flex' }}>Loading...</div>}
      <div id="generated-content">
        {error && <p className="error">{error}</p>}
        {story && (
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <p dangerouslySetInnerHTML={{ __html: story }} style={{ flex: 1 }} />
            <button onClick={copyToClipboard} className="icon-button" style={{ marginLeft: '10px' }}>
              <i className="fas fa-copy"></i>
            </button>
            <button onClick={readAloud} className="icon-button" style={{ marginLeft: '10px' }}>
              <i className="fas fa-volume-up"></i>
            </button>
            <button onClick={toggleLike} className="icon-button" style={{ marginLeft: '10px' }}>
              <i className={`fas fa-thumbs-${liked ? 'up' : 'down'}`}></i>
            </button>
            <button onClick={regenerateStory} className="icon-button" style={{ marginLeft: '10px' }}>
              <i className="fas fa-redo"></i>
            </button>
            {copied && <span style={{ marginLeft: '10px', color: 'green' }}>Copied!</span>}
          </div>
        )}
        {photos.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between' }}>
            {photos.map((photo, index) => (
              <img 
                key={index} 
                src={photo} 
                alt="Generated Photo" 
                className="generated-photo" 
                style={{ width: '30%', height: 'auto', margin: '10px 0' }} // Adjust width for uniformity
              />
            ))}
          </div>
        )}
      </div>
      <style jsx>{`
        .icon-button {
          border: none;
          background-color: #000;
          color: #fff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 35px;
          height: 35px;
          border-radius: 50%;
          font-size: 1.2em;
          transition: background-color 0.3s ease, box-shadow 0.2s ease;
        }

        .icon-button:hover {
          background-color: #333;
          box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        .error {
          color: red;
        }

        .generated-photo {
          object-fit: cover;
        }
      `}</style>
    </div>
  );
};

export default StoryGenerator;
