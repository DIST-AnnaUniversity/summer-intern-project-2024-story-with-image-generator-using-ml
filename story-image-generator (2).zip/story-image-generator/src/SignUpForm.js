import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import the navigate hook

const SignUpForm = () => {
  // State to manage form input values
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    mobile: '',
  });

  // Hook for navigation
  const navigate = useNavigate();

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform form validation or API submission here

    // Redirect to another page after successful signup
    navigate('/login');
  };

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div className="signup-page">
      <form onSubmit={handleSubmit}>
        <h2>Registration Form</h2><br />

        <label htmlFor="name">Username:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
          required
        /><br />

        <label htmlFor="email">Email ID&nbsp;:</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          required
        /><br />

        <label htmlFor="password">Password&nbsp;:</label>
        <input
          type="password"
          id="password"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          required
        /><br />

        <label htmlFor="mobile">Mobile&nbsp;&nbsp;:</label>
        <input
          type="tel"
          id="mobile"
          name="mobile"
          value={formData.mobile}
          onChange={handleInputChange}
          required
        /><br /><br />

        <input type="submit" value="Sign Up" /><br /><br />

        Already have an account? <a href="/login">Login</a>
      </form>
    </div>
  );
};

export default SignUpForm;
