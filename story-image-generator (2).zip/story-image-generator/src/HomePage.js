// src/HomePage.js
import React from 'react';
import './HomePage.css';

const HomePage = () => {
    return (
        <div className="container">
            <h1>Welcome to Our Platform</h1>
            <p>Your journey to success starts here. Explore our features!</p>
            <div className="button-container">
                <a href="/login" className="button">Login</a>
                <a href="/register" className="button">Register</a>
            </div>
        </div>
    );
};

export default HomePage;
