import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, useNavigate } from 'react-router-dom';
import StoryGenerator from './StoryGenerator';
import HistoryPage from './HistoryPage';
import HomePage from './HomePage';
import RegisterPage from './RegisterPage';
import LoginPage from './LoginPage';
import './style.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

const App = () => {
    const [sidebarVisible, setSidebarVisible] = useState(true);
    const navigate = useNavigate(); // Initialize useNavigate

    const toggleSidebar = () => {
        setSidebarVisible(!sidebarVisible);
    };

    const handleLogin = (credentials) => {
        // Add your authentication logic here (e.g., API call)
        console.log('Login attempt:', credentials);

        // If login is successful, navigate to the story generator page
        navigate('/story-generator');
    };

    return (
        <div className="app">
            {/* Sidebar toggle button */}
            <button className="sidebar-toggle" onClick={toggleSidebar}>
                {sidebarVisible ? '☰' : '☰'}
            </button>

            {/* Sidebar */}
            <div className={`sidebar ${sidebarVisible ? '' : 'hidden'}`}>
                <div className="sidebar-logo">
                    <img
                        src="https://i.postimg.cc/hP0HLRnx/Manu1-23.jpg"
                        alt="Logo"
                        className="sidebar-logo-img"
                    />
                    <h2>AI Story Generator</h2>
                </div>
                <div className="sidebar-nav">
                    <Link to="/" className="sidebar-button">Home</Link>
                    <Link to="/history" className="sidebar-button">History</Link>
                    <button className="sidebar-button" onClick={() => {
                        // Add your log out logic here
                        console.log("Logging out...");
                        navigate('/login'); // Navigate to login on logout
                    }}>Log Out</button>
                </div>
            </div>

            {/* Main content area */}
            <div className="main-content">
                <div className="header">
                    <h1>
                        AI Story Generator
                        <img
                            src="https://i.postimg.cc/hP0HLRnx/Manu1-23.jpg"
                            alt="Manu"
                            className="profile-img"
                        />
                    </h1>
                </div>
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/login" element={<LoginPage onLogin={handleLogin} toggleView={() => navigate('/register')} />} />
                    <Route path="/story-generator" element={<StoryGenerator />} />
                    <Route path="/history" element={<HistoryPage />} />
                </Routes>
                <footer className="footer">
                    <p>
                        &copy; All rights reserved. Story & Image Generator by
                        <span>
                            <a href="ASVAJITH">b</a>
                        </span>
                    </p>
                </footer>
            </div>

            {/* Input bar for story generation */}
            <div className="input-bar">
                <input
                    type="text"
                    id="story-input"
                    placeholder="Type your story here..."
                />
                <button className="icon-button generate-story-button" onClick={() => navigate('/story-generator')}>
                    <span className="icon">📝</span>
                </button>
                <button className="icon-button generate-image-button">
                    <span className="icon">🖼️</span>
                </button>
            </div>
        </div>
    );
};

// Wrap the App component with Router
const Root = () => (
    <Router>
        <App />
    </Router>
);

export default Root;
