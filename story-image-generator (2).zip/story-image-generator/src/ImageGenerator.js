import React, { useState } from 'react';

// Your Hugging Face API token
const HUGGING_FACE_API_KEY = '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'; // Replace with your Hugging Face API key

const ImageGenerator = () => {
  const [imageUrl, setImageUrl] = useState('');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const generateImage = async () => {
    setLoading(true);
    setError('');

    if (!prompt.trim()) {
      setError('Please enter a prompt to generate an image.');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('https://api-inference.huggingface.co/models/CompVis/stable-diffusion-v1-4', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${HUGGING_FACE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: prompt,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }

      const data = await response.blob(); // Receive the response as a blob (image data)
      const imageObjectURL = URL.createObjectURL(data); // Create an image URL from the blob
      setImageUrl(imageObjectURL); // Set the image URL to display
    } catch (err) {
      setError(`Failed to generate image: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Enter a prompt to generate an image"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        style={{ marginBottom: '10px', padding: '5px' }}
      />
      <button onClick={generateImage} style={{ marginLeft: '10px' }}>Generate Image</button>
      
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {imageUrl && <img src={imageUrl} alt="Generated" style={{ marginTop: '10px', width: '300px' }} />}
    </div>
  );
};

export default ImageGenerator;
