// Import Font Awesome Icons
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';

const NavBar = () => {
  return (
    <div className="navbar">
      <div className="nav-left">
        <button className="sidebar-toggle" onClick={toggleSidebar}>
          {/* Sidebar toggle button */}
        </button>
      </div>
      
      <div className="nav-right">
        {/* Profile icon */}
        <FontAwesomeIcon
          icon={faUserCircle}
          className="profile-icon"
          title="Profile"
        />
      </div>
    </div>
  );
};

export default NavBar;
