// src/StoryPage.js
import React from 'react';
import './style.css'; // Import the same stylesheet for consistency

const StoryPage = () => {
  return (
    <div className="story-page">
      <h2>Story Generation</h2>
      <div className="input-bar">
        <input
          type="text"
          id="story-input"
          placeholder="Type your story here..."
        />
        <button className="icon-button generate-story-button">
          <span className="icon">📝</span>
          Generate Story
        </button>
        <button className="icon-button generate-image-button">
          <span className="icon">🖼️</span>
          Generate Image
        </button>
      </div>
    </div>
  );
};

export default StoryPage;
