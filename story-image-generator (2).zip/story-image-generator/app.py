from flask import Flask, request, jsonify
import torch
from transformers import GPT2LMHeadModel, GPT2TokenizerFast
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable Cross-Origin requests

# Load the tokenizer and model once when the application starts
model_directory = r'C:\Users\asvaj\story-image-generator\gpt2-large-fairytales'
tokenizer = GPT2TokenizerFast.from_pretrained(model_directory)
model = GPT2LMHeadModel.from_pretrained(model_directory)
model.eval()  # Set the model to evaluation mode

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)  # Move the model to GPU if available

def generate_story(prompt):
    # Input prompt for text generation
    inputs = tokenizer.encode(prompt, return_tensors='pt').to(device)  # Move inputs to GPU
    
    # Generate attention mask
    attention_mask = torch.ones(inputs.shape, dtype=torch.long).to(device)  # Move attention mask to GPU

    # Generate text using the model
    outputs = model.generate(
        inputs,
        max_length=200,
        num_return_sequences=1,
        no_repeat_ngram_size=2,
        repetition_penalty=1.5,
        top_p=0.95,
        temperature=0.9,
        do_sample=True,  # Enable sampling-based generation
        pad_token_id=tokenizer.eos_token_id,
        attention_mask=attention_mask
    )

    # Decode and return the generated text
    generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    return generated_text

@app.route('/generate-fairy-tale', methods=['POST'])
def generate_fairy_tale():
    # Check if the request is JSON
    if not request.is_json:
        return jsonify({'error': 'Request must be JSON'}), 400

    # Get the JSON data
    data = request.get_json()
    prompt = data.get('prompt', 'Once upon a time')

    # Validate the prompt
    if not isinstance(prompt, str) or not prompt.strip():
        return jsonify({'error': 'Prompt must be a non-empty string'}), 400

    try:
        # Call the generate_story function to get the fairy tale
        generated_story = generate_story(prompt)
        # Print the generated story in the console
        print("Generated Story:", generated_story)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

    # Return the generated story as a JSON response
    return jsonify({'story': generated_story})

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
