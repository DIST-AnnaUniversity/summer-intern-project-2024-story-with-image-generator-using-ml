import torch
from transformers import GPT2Tokenizer, GPT2LMHeadModel

# Load the tokenizer and model
tokenizer = GPT2Tokenizer.from_pretrained(r'C:\Users\asvaj\story-image-generator\gpt2-large-fairytales')
model = GPT2LMHeadModel.from_pretrained(r'C:\Users\asvaj\story-image-generator\gpt2-large-fairytales')

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)  # Move the model to GPU if available

# Input prompt for text generation
prompt = "Once upon a time"
inputs = tokenizer.encode(prompt, return_tensors='pt').to(device)  # Move inputs to GPU

# Debug print
print("Input encoded. Starting text generation...")

# Generate attention mask
attention_mask = torch.ones(inputs.shape, dtype=torch.long).to(device)  # Move attention mask to GPU

# Generate text using the model
outputs = model.generate(
    inputs,
    max_length=200,
    num_return_sequences=1,
    no_repeat_ngram_size=2,
    repetition_penalty=1.5,
    top_p=0.95,
    temperature=0.9,
    do_sample=True,  # Enable sampling-based generation
    pad_token_id=tokenizer.eos_token_id,
    attention_mask=attention_mask
)

# Debug print to check output tensor
print("Model output:", outputs)

# Decode and print the generated text
# Decode and print the generated text
generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)  # You can set this to False if preferred

# Print the generated text
print("Generated Text:", generated_text)
